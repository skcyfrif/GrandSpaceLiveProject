//package com.cyfrifpro.exception;
//
//public class JwtTokenException extends RuntimeException {
//
//	private String message;
//
//	public JwtTokenException(String message) {
//		super(message);
//		this.message = message;
//	}
//
//	@Override
//	public String getMessage() {
//		return this.message;
//	}
//}
