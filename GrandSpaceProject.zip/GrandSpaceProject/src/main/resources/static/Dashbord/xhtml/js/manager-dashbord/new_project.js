document.addEventListener("DOMContentLoaded", async function () {
    console.log("Script loaded and DOM is ready.");

    // Retrieve Bearer Token from sessionStorage
    const token = sessionStorage.getItem("authToken"); 

    if (!token) {
        console.error("No token found in sessionStorage");
        return;
    }

    try {
        const response = await fetch("http://localhost:9090/api/project/awaiting-estimates-last-year", {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`  // Add token in Authorization header
            }
        });

        console.log("Fetching API...");
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();
        console.log("API Response:", data);

        if (data && data.length > 0) {
            const project = data[0];

            console.log("Project Data:", project);

            document.getElementById("project-id").textContent = project.id || "N/A";
            document.getElementById("registration-date").textContent = project.registrationDate || "N/A";
            document.getElementById("bid-type").textContent = project.bidType || "BID";
        } else {
            console.warn("No projects found");
        }
    } catch (error) {
        console.error("Error fetching project data:", error);
    }
});
