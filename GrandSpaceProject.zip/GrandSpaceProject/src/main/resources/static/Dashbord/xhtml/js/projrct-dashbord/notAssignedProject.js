document.addEventListener("DOMContentLoaded", function () {
    const API_BASE_URL = "http://localhost:9090"; // Replace with actual base URL
    const notAssignedProject = document.getElementById("notAssignedProject");

    // Retrieve token from sessionStorage
    const token = sessionStorage.getItem("authToken");

    if (!token) {
        console.error("No token found in sessionStorage. Authorization required.");
        notAssignedProject.textContent = "Unauthorized";
        return;
    }

    // Fetch the total unassigned project count
    fetch(`${API_BASE_URL}/api/project/projects/un-publish/count`, {
        method: "GET",
        headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        notAssignedProject.textContent = data; // Update UI with count
    })
    .catch(error => {
        console.error("Error fetching project count:", error);
        notAssignedProject.textContent = "Error";
    });
});

// Function to fetch all projects and update the table
document.addEventListener("DOMContentLoaded", function () {
    async function fetchProjects() {
        const API_BASE_URL = "http://localhost:9090";
        const token = sessionStorage.getItem("authToken");

        if (!token) {
            console.error("No token found in sessionStorage. Authorization required.");
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/project/un-publish-projects`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                }
            });

            if (!response.ok) {
                throw new Error(`Failed to fetch projects: ${response.status} ${response.statusText}`);
            }

            const projects = await response.json();
            const tbody = document.querySelector("#projects tbody");
            tbody.innerHTML = ""; // Clear existing table rows

            projects.forEach(project => {
                const row = document.createElement("tr");

                row.innerHTML = `
                    <td>${project.projectCode}</td>
                    <td>${project.name}</td>
                    <td>${project.status}</td>
                    <td>${project.clientName}</td>
                    <td>${project.assignedManager || "Not Assigned"}</td>
                    <td>${project.description}</td>
                    <td>${project.registrationDate}</td>
                    <td>
                        <button class="btn btn-danger delete-btn" data-id="${project.id}">Delete</button>
                        <button class="btn btn-primary publish-btn" data-id="${project.id}">Publish</button>
                    </td>
                `;

                tbody.appendChild(row);
            });

            // Attach event listeners for delete buttons
            document.querySelectorAll(".delete-btn").forEach(button => {
                button.addEventListener("click", function () {
                    const projectId = this.getAttribute("data-id");
                    deleteProject(projectId);
                });
            });

            // Attach event listeners for publish buttons
            document.querySelectorAll(".publish-btn").forEach(button => {
                button.addEventListener("click", function () {
                    const projectId = this.getAttribute("data-id");
                    publishProject(projectId);
                });
            });
        } catch (error) {
            console.error("Error fetching projects:", error);
        }
    }

    // Function to delete a project
    async function deleteProject(projectId) {
        const API_BASE_URL = "http://localhost:9090";
        const token = sessionStorage.getItem("authToken");

        if (!token) {
            console.error("No token found in sessionStorage. Authorization required.");
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/project/delete/${projectId}`, {
                method: "DELETE",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                }
            });

            if (response.ok) {
                alert("Project deleted successfully");
                fetchProjects(); // Refresh table
            } else {
                alert("Error deleting project");
            }
        } catch (error) {
            console.error("Error deleting project:", error);
        }
    }

    // Function to publish a project
    async function publishProject(projectId) {
        const API_BASE_URL = "http://localhost:9090";
        const token = sessionStorage.getItem("authToken");

        if (!token) {
            console.error("No token found in sessionStorage. Authorization required.");
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/api/project/${projectId}/assign-to-managers`, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                }
            });

            if (response.ok) {
                alert("Project published successfully");
                fetchProjects(); // Refresh table
            } else {
                alert("Error publishing project");
            }
        } catch (error) {
            console.error("Error publishing project:", error);
        }
    }

    // Fetch projects on page load
    fetchProjects();
});
