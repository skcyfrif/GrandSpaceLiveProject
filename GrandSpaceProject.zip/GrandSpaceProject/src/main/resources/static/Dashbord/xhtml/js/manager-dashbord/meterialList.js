document.addEventListener("DOMContentLoaded", async () => {
    const tableBody = document.querySelector("#tbodyy");

    try {
        // Fetch data from the API
        // const API_BASE_URL = "https://www.grandspace.co.in";
        const API_BASE_URL = "http://localhost:9090";

        const response = await fetch(`${API_BASE_URL}/api/vendors/all`);

        if (response.ok) {
            const vendors = await response.json(); // Parse the response as JSON

            // Iterate over each vendor and their material requirements
            vendors.forEach(vendor => {
                vendor.materialDetails.forEach(material => {
                    // console.log(vendor);
                    
                    // Create a new table row for each material
                    const row = `
                        <tr>
                            <td>${vendor.projectId}</td>
                            <td>${material.materialName}</td>
                            <td>${material.quantity}</td>
                            <td>${material.quality}</td>
                            <td>${vendor.lastDate}</td>
                            <td>${material.status}</td>
                        </tr>
                    `;
console.log(row);

                    // Append the row to the table body
                    tableBody.innerHTML += row;
                });
            });
        } else {
            console.error("Failed to fetch vendors. Status:", response.status);
            alert("Failed to fetch data from the API.");
        }
    } catch (error) {
        console.error("Error fetching vendors:", error);
        alert("An error occurred while fetching data.");
    }
});
