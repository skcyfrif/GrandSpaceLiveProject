package com.cyfrifpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrandSpaceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
